exports.initRoutes = (app) => {
    require('./interview.route').errorRoute(app)
    
  }