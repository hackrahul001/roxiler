
const errorService = require('../services/user.service')
const { auth } = require('../middleware/userAuth.middleware')



exports.errorRoute = (app) => {
    // app.get('/');

   
}


