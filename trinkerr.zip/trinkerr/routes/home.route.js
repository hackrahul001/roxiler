
const errorService = require('../services/home.service')



exports.errorRoute = (app) => {
    // app.get('/');
   
}


