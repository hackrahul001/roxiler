
function admin(){
document.getElementById('admin').click()
}



