const dotenv = require('dotenv').config();
exports.APP_CONFIG = {
  SECRET_KEY : 'trinkerr',
}